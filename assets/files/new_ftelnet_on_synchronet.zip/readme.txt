These files are for the DEFAULT Synchronet web interface.  If you're using ecWeb, or anything else, then I
haven't looked into what's required so I'm happy to help, but there's no ready-to-go files for you yet.

Step 1) Put externals.ssjs in /sbbs/web/root/members

Step 2a) If you're using the default theme: Put ftelnet_external.inc in /sbbs/web/templates/default

Step 2b) If you're using the nightshade theme: Open /sbbs/web/templates/nightshade/ftelnet_external.inc
         and replace the contents between <!-- fTelnet --> and <!-- end fTelnet --> with the contents
         between those same tags in the new ftelnet_external.inc

Step 3) Put ftelnethelper.js in /sbbs/exec/load

ftelnet_external.inc is set to route requests through one of my public proxies, proxy-us-ga.ftelnet.ca, 
which is based in Georgia.  There's also proxy-us-nj for New Jersey, proxy-us-ca for California, and
proxy-nl for Netherlands, so feel free to change that setting if you'd like.

If you'd rather use your own proxy, you'll need to use https://github.com/rickparrish/fTelnetProxy
Just get it running, then update ftelnet_external.inc to point ProxyHostname and ProxyPort to the right
location (ie localhost on port 1123).  NOTE: On Linux this needs mono, since it's a .NET app

If enough people show interest, I'll look into updating the Synchronet CVS with a local install of
fTelnet (so no dependence on my web server or proxies) -- it's way easier for me just to support this
embedded version, which is why I'm going this route for now.

Oh yeah, don't forget to backup the files you're replacing first :)